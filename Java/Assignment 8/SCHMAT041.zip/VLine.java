//Matthew Schramm
//2022/10/11
//Question 1
//Assignment 8

/*public class VLine extends VectorObject{
   public int length;
   public VLine(int id, int x , int y, int l){
      super(id,x,y);
      length = l;
   }
   }
  */